<?php
return array(
	//'配置项'=>'配置值'
	'TMPL_PARSE_STRING'=>array(
	  '__JS__'=>__ROOT__.'/Public/js',
	  '__CSS__'=>__ROOT__.'/Public/css',
	  '__IMG__'=>__ROOT__.'/Public/images',
	  '__PLUG__'=>__ROOT__.'/Public/plug',
	),
	'copyright'=>"技术支持：开利网络"
);