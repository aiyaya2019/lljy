<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class AgentAdminController extends CommonController {
    public function __construct(){
    	parent::__construct();
        $agent = $this->finddata('agent',array('members_id'=>$this->members_id));
        if ($agent['status'] == 1) {
            $_SESSION['agent_id'] = $agent['id'];
        }else{
            $this->redirect('Members/index');
        }
	}
    /* 分销商-----------会员中心首页 */
    public function index(){
        $agent_id = $_SESSION['agent_id'];
        if ($agent_id) {
            $data = D('AgentRelation')->relation(true)->where(array('id'=>$agent_id))->find();
            $this->data = $data;
        }
        $this->title = "分销中心";
    	$this->display();
    }
    /* 分销商-----------会员中心首页 */
    public function editInfo(){
        $id = I('get.id');
        if ($id) {
            $data = $this->finddata('agent',array('id'=>$_SESSION['agent_id']));
            $title = "我的资料";
        }else{
            $data = $this->finddata('agent',array('id'=>$_SESSION['agent_id']));
            $title = "分销商申请"; 
        }
        $this->data = $data;
        $this->title = $title;
    	$this->display();
    }
    /* 分销商-----------会员中心首页 */
    public function editInfoHandel(){
        $id = I('get.id');
        $data = I('post.');
        if($id){
            $arr = explode(',',$data['address']);
            $data['province'] = $arr[0];
            $data['city'] = $arr[1];
            $data['area'] = $arr[2];
            $rs = M('agent')->where(array('id'=>$id))->data($data)->save();
        }
        if ($rs){
            $this->ajaxReturn(array('code'=>6,'msg'=>"修改成功"));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>"操作失败"));
        }
    }
    /* 我的下线伙伴 */
    public function mypartner(){
        $top_id = I('get.top_id',$this->members_id);
        $data = $this->selectdata('members',array('top_id'=>$top_id));
        $this->data = $data;
    	$this->title = "我的客户";
    	$this->display();
    }
    /* 我的二维码 */
    public function mycode(){
        $share = $this->finddata('share_config',array('id'=>1));
        $this->share = $share;
        $data = M('members')->where(array('id'=>$this->members_id))->find();
        if (!$data['barcode']) {
             import('Class.phpqrcode',APP_PATH);   //引入外部类
            $mycode = randomCode(2,6);
            $value = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].'/Index/Index/index/top_id/'.$this->members_id; //二维码内容 
            $errorCorrectionLevel = 'L';  //容错级别 
            $matrixPointSize = 16;        //生成图片大小 
            //生成二维码图片 
            \QRcode::png($value,'Uploads/Admin/barcode/'.$mycode.'.png', $errorCorrectionLevel, $matrixPointSize, 2);
            //拼接二维码路径必须带http整体
            $filename = '/Uploads/Admin/barcode/'.$mycode.'.png';
            //设置字段二维码数据
            M('members')->where(array('id'=>$this->members_id))->setField('barcode',$filename);
            $data = M('members')->where(array('id'=>$this->members_id))->find();
        }
        $this->data = $data;
        /* 微信公众号分享 */
        $this->sharedata = $this->share(2);
        $this->title = "我的专属码";
        $this->display();
    }
}