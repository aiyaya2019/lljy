<?php
namespace Index\Controller;
use Think\Controller;
class CashController extends CommonController {
    //新闻列表页
    public function cash(){
        $data = D('CashRelation')->relation(true)->where(array('members_id'=>$this->members_id))->select();
        foreach ($data as $k => $v) {
            $data[$k]['bank_name'] = $this->finddata('bank_cate',array('id'=>$v['bank_cate_id']),'name');
        }
        // dump($data);
        $this->data = $data;
        $this->title="佣金提现";
        $this->display();
    }
    //新闻列表页
    public function cash_apply(){
        $bank = D('BankRelation')->relation(true)->where(array('members_id'=>$this->members_id))->select();
        $this->bank = $bank;
        $members = $this->finddata('members',array('id'=>$this->members_id));
        $this->members = $members;
        /* 判断是否开启提现 */
        $cash_date = getBase("cash_date");
        $cash_date = explode("、",$cash_date);
        $weekarray=array("周日","周一","周二","周三","周四","周五","周六");
        $weekday = $weekarray[date("w")];
        $is_cash = false;       
        foreach ($cash_date as $k => $v) {
           if ($v==$weekday) {
               $is_cash = true;
           }
        }
        $this->is_cash = $is_cash;
        $this->title="佣金提现";
        $this->display();
    }
    // 提现的表单处理
    public function cash_applyHandel(){
        if (!IS_AJAX) E('非法请求');
        $data = I('post.');
        $data1 = array(
            'members_id'=>$this->members_id,
            'bank_id'=>$data['bank_id'],
            'create_time'=>time(),
            'money'=>$data['commission'],
            'messages'=>$data['messages']
        );
        $rs1 = $this->adddata('cash',$data1);
        $data2 = array(
            'type'        =>2,
            'commission'  =>'-'.$data['commission'],
            'msg'         =>date('m月d日').'佣金提现',
            'members_id'  =>$this->members_id,
            'create_time' =>time(),
        );
        $rs2 = $this->adddata('commission_change',$data2);
        if($rs1 & $rs2){
            $this->ajaxReturn(array('code'=>6,'msg'=>'success'));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'提现失败，请重试'));
        }
    }
	// 银行卡列表页
    public function bank(){
        $data = D('BankRelation')->relation(true)->where(array('members_id'=>$this->members_id))->select();
        $this->data = $data;
    	$this->title="我的银行卡";
    	$this->display();
    }
    /* 添加/编辑有银行卡 */
    public function bank_edit(){
        $id = I("get.id");
        if ($id){
           $data = D('BankRelation')->relation(true)->where(array('id'=>$id))->find();
           $this->data = $data;
           $title = "编辑".$data['bank_name']."银行卡";
        }
        $title = $title ? $title : "添加银行卡";
        $this->bank_cate = M('bank_cate')->where(array('status'=>0))->select();
        $this->title=$title;
        $this->display();
    }
    /* 添加/编辑银行卡表单处理*/
    public function bank_editHandel(){
        if(!IS_AJAX) E('非法访问');
        $data = array(
            'members_id'=>$this->members_id,
            'bank_cate_id'=>I('post.bank_cate_id'),
            'bank_number'=>I('post.bank_number'),
            'create_time'=>time(),
            'bank_username'=>I('post.bank_username')
        );
        if ($id = I('get.id')) {
            $rs = M('bank')->where(array('id'=>$id))->data($data)->save();
            $msg ="修改成功";
        }else{
            $rs = M('bank')->data($data)->add();
            $msg ="添加成功";
        }
        if($rs){
            $this->ajaxReturn(array('code'=>6,'msg'=>$msg));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>$msg));
        }
    }
    public function money_list(){
        /*查询剩余金额*/
        $have_money = $this->finddata('members',array('id'=>$this->members_id),'commission');
        /* 佣金已提现统计 */
        $where = "type = 2 or type = 3 and members_id=".$this->members_id;
        $cash_money = M('commission_change')->where($where)->sum('commission');
        /* 佣金返佣统计 */
        $where = array('type'=>1,'members_id'=>$this->members_id);
        $rebate_money = M('commission_change')->where($where)->sum('commission');

        $this->money = array(
            'have_money'=>$have_money,
            'cash_money'=>$cash_money,
            'rebate_money'=>$rebate_money
        );
        /* 财务记录 */
        $data = $this->selectdata('commission_change',array('members_id'=>$this->members_id));
        $this->data = $data;
        $this->title='我的佣金';
        $this->display();
    }
}