<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class GroupMallController extends CommonController {
    // 拼团商城首页
    public function index(){
        /* 获取拼团首页banner图 */
        $banner = $this->getBanner(3);
        $this->banner = $banner;

        /* 获取首页头部导航 */
        $top_nav = $this->selectdata('top_nav',array('status'=>0,'place'=>3),'','sort ASC');
        $this->top_nav = $top_nav;
        
        /* 获取推荐商品 */
        $goods_red = $this->selectdata('group_goods',array('status'=>0,'is_red'=>1));
        $this->goods_red = $goods_red;

        /* 微信公众号分享 */
        $this->sharedata = $this->share(1);
        $this->title = "拼团商城";
        $this->display();
    }
    // 获取拼团商品列表
    public function goodslist(){
        /* 模糊查询商品 */
        $name = I('get.name');
        if ($name) {
           $where['name'] = array("like","%$name%");
        }
        $type = I('get.type');
        if ($type) {
           $where[$type] = 1;
           switch ($type) {
                case 'is_red':
                   $title = "推荐商品";
                   break;
                case 'is_new':
                   $title = "新品推荐";
                   break;
           }
        }
        /*判断是否有传过来的分类id*/
        $cate_id = I('get.cate_id');
        if ($cate_id) {
		   $goods_cate = M('goods_cate')->where(array('status'=>0))->select();
		   $idStr = getIdStr($goods_cate,$cate_id);
		   $where['goods_cate_id '] = array('in',$idStr);
           $name = M('goods_cate')->where(array('id'=>$cate_id,'status'=>0))->getField('name');
           $title = $name;
        }
        $where['status'] = 0;
        $data = $this->selectdata('goods',$where,'');
        // dump($data);
        $this->data = $data;
        $this->logo = $this->getConfig('logo');
        $this->title= $title ? $title : "全部商品";
        $this->display();
    }

    /* 拼团商品详情页 */
    public function details(){
        $goods_id = I('get.id');
        $data = D('GroupGoodsRelation')->relation(true)->where(array('id'=>$goods_id))->find();
        $data['many_pic'] = json_decode($data['many_pic']);
        // dump($data);
        $this->data = $data;
        $waitOrder = D("GroupOrderRelation")->relation(true)->order("id desc")->where(array('status'=>1,'group_goods_id'=>$goods_id))->select();
        foreach ($waitOrder as $k => $v) {
            $buy_num = M("group_order_buy")->where(array('ordercode'=>$v["ordercode"],'status'=>1))->count();
            $waitOrder[$k]["poor"] = $v["group_num"]-$buy_num;
        }
        $this->waitOrder = $waitOrder;
        $this->title= $data['name'];
        $this->sharedata = $this->sharePackage($data['pic'],$data['name'],$data['title']);
        $this->display();
    }
   
    /* 订单确认页面 */
     public function confirm(){
        //获取用户收货地址
        $address_id = I('get.address_id');
        if ($address_id){
            $address = $this->finddata('address',array('id'=>$address_id));
        }else{
            $address = $this->finddata('address',array('members_id'=>$this->members_id,'default'=>1));
        }
        $this->address = $address;
        $goods = $_SESSION['group_buy'];
        // dump($goods);
        $this->goods = $goods;
        $this->title = "订单确认";
        $this->display();
    }

    public function buyOrder(){
        $data = I("post.");
        $_SESSION["group_buy"] = $data;
        $this->ajaxReturn(array('code'=>6,"msg"=>"存储成功"));
    }
    // 参加团
    public function joinGroup($buydata,$post){
        $sub_ordercode = randomCode();
        $allmoney = ($buydata["price"]*$buydata["num"])+getBase('postage');
        $_SESSION['pay']['url'] = array(
            'addordesUrl'=>U('GroupMall/payOrder'),
            'successUrl'=>U('Status/status',array('type'=>1)),
            'returnUrl'=>U('GroupMall/order',array('status'=>1)),
        );
        $_SESSION['pay']['data'] = array(
            'table'=>'group_order_buy',
            'ordercode'=>$sub_ordercode,
            'money'=>$allmoney,
            'title'=>'拼团订单支付',
        );
        $group_order_buy = array(
            "ordercode"     =>  $buydata['ordercode'],
            "sub_ordercode" =>  $sub_ordercode,
            "group_goods_id"=>  $buydata["id"],
            "num"           =>  $buydata["num"],
            "price"         =>  $buydata["price"],
            "allmoney"      =>  $allmoney,
            "paymoney"      =>  $allmoney,
            "address_id"    =>  $post['address_id'],
            "members_id"    =>  $this->members_id,
            "attr"          =>  json_encode($buydata["attr"]),
            "messages"      =>  $post['messages'],
            "create_time"   =>  time()
        );
        $_SESSION["group_order_buy"] = $group_order_buy;
        $rs = $this->adddata("group_order_buy",$group_order_buy);
        return array("code"=>6,"msg"=>"参团订单添加成功",'ordercode'=>$buydata['ordercode']);
    }
    // 创建团
    public function createGroup($buydata,$post){
        $ordercode = randomCode();
        $sub_ordercode = randomCode();
        $where = array('id'=>$buydata["id"]);
        $goods = $this->finddata("group_goods",$where);
        $allmoney = ($buydata["price"]*$buydata["num"])+getBase('postage');
        $endtime = time()+(getBase("group_endtime")*3600);
        $order = array(
            'ordercode'           => $ordercode,
            'group_goods_id'      => $buydata["id"],
            'members_id'          => $this->members_id,
            'create_time'         => time(),
            'type'                => 1,
            'endtime'             => $endtime
        );
        // 单独购买
        if ($buydata['type']==1) {
            $order["group_num"] = 1;
        }else if($buydata['type']==2){        // 拼团
            $order["group_num"] = $goods["group_num"];
        }
        $rs = M('group_order')->add($order);
        if($rs){
            $_SESSION['pay']['url'] = array(
                'addordesUrl'=>U('GroupMall/payOrder'),
                'successUrl'=>U('Status/status',array('type'=>1)),
                'returnUrl'=>U('GroupMall/order',array('status'=>1)),
            );
            $_SESSION['pay']['data'] = array(
                'table'=>'group_order_buy',
                'ordercode'=>$sub_ordercode,
                'money'=>$allmoney,
                'title'=>'拼团订单支付',
            );
            $group_order_buy = array(
                "ordercode"     =>  $ordercode,
                "sub_ordercode" =>  $sub_ordercode,
                "group_goods_id"=>  $buydata["id"],
                "num"           =>  $buydata["num"],
                "price"         =>  $buydata["price"],
                "allmoney"      =>  $allmoney,
                "paymoney"      =>  $allmoney,
                "address_id"    =>  $post['address_id'],
                "members_id"    =>  $this->members_id,
                "attr"          =>  json_encode($buydata["attr"]),
                "messages"      =>  $post['messages'],
                "create_time"   =>  time()
            );
            $_SESSION["group_order_buy"] = $group_order_buy;
            $this->adddata("group_order_buy",$group_order_buy);
            return array('code'=>6,'msg'=>'订单添加成功','ordercode'=>$ordercode);
        }else{
            return array('code'=>1,'msg'=>'订单添加失败');
        }
    }
    /* 拼团商城添加订单的方法 */
    public function addOrder(){
        $buydata = $_SESSION["group_buy"];
        $post = I("post.");
        if (!$buydata) {
           $this->ajaxReturn(array('code'=>1,'msg'=>'请重新选购'));
        }
        if ($buydata['ordercode']) {  // 参团
            $result = $this->joinGroup($buydata,$post);
        }else{   // 发起拼团
            $result = $this->createGroup($buydata,$post);
        }
        $this->ajaxReturn($result);
    }
    /* 修改拼团订单状态 */
    public function payOrder(){
        $pay_type = I("post.pay_type");
        $group_order_buy = $_SESSION["group_order_buy"];
        $ordercode = $group_order_buy["ordercode"];
        $map = array(
            'sub_ordercode' =>   $group_order_buy["sub_ordercode"]
        );
        $buyArr = array(
            "status"        =>   1,
            "pay_type"      =>   $pay_type,
            "update_time"   =>   time()
        );
        $rs = M("group_order_buy")->where($map)->data($buyArr)->save();
        $where1 = array('ordercode'=>$ordercode);
        $group_num = $this->finddata("group_order",$where1,"group_num");

        $where2 = array('ordercode'=>$ordercode,"status"=>1);
        $group_buy_num = M("group_order_buy")->where($where2)->count();

        if ($group_num == $group_buy_num) {
            M("group_order_buy")->where($where1)->setField("status",2);
            M("group_order")->where($where1)->setField("status",2);
        }else{
            M("group_order")->where($where1)->setField("status",1);
        }
        if ($rs) {
           $this->ajaxReturn(array('code'=>6,'msg'=>'修改订单状态成功'));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'修改订单状态失败'));
        }
    }

    // 获取商品属性
    public function getGroupGoodsAttr(){
       $goods_id = I('post.goods_id');
        $data = D('GroupGoodsAttrCateRelation')->relation(true)->where(array('goods_id'=>$goods_id))->order('id ASC')->select();
        foreach ($data as $key => $row) {
           $volume[$key]  = $row['id'];
           $edition[$key] = count($row['attr_option']);
        }
        /* 双数组合并排序 */
        array_multisort($edition, SORT_ASC,$volume, SORT_ASC, $data);
        $newdata = $data;
        if ($newdata){
            $this->ajaxReturn(array('code'=>6,'msg'=>'获取成功','data'=>$newdata));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'没有属性'));
        }
    }
    public function getGroupGoodsAttrval(){
        $goods_id = I('post.goods_id');
        $attr_val = I('post.attr_val');
        $data = $this->finddata('group_goods_attr_list',array('goods_id'=>$goods_id,'attr_val'=>$attr_val));
        if ($data){
            $this->ajaxReturn(array('code'=>6,'msg'=>'获取成功','data'=>$data));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'没有库存了'));
        }
    }

     /* 订单状态 */
    public function order(){
        $status = I("get.status",1);;
        $where['members_id'] = $this->members_id;
        if(isset($status)){
            $where['status'] = $status;
        }
        $data = D('GroupOrderBuyRelation')->relation("group_goods")->where($where)->select();
        // dump($data);
        // die;
        foreach ($data as $k => $v) {
            $attr = json_decode($v['attr'],1);
            $data[$k]['attr'] =$attr ;
        }
        // $data = M('group_order')->where($where)->order('id desc')->select();
        // foreach ($data as $k => $v) {
        //     $list = D('GroupOrderBuyRelation')->relation("group_goods")->where(array('ordercode'=>$v['ordercode'],"members_id"=>$this->members_id))->find();
        //     $attr = json_decode($list['attr'],1);
        //     $list['attr'] =$attr ;
        //     $data[$k]["child"] = $list;
        // }
        // dump($data);
        // die;
        $this->data = $data;
        $this->title="拼团订单";
        $this->display();
    }

    /* 修改订单状态 */
    public function upField(){
        $sub_ordercode = I('post.sub_ordercode');
        $status = I('post.status');
        $rs = M('group_order_buy')->where(array('sub_ordercode'=>$sub_ordercode))->setField('status',$status);
        if ($rs) {
            $this->ajaxReturn(array('code'=>6,'msg'=>'操作成功'));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'操作失败'));
        }
    }
    // 删除取消的订单
    public function delOrder(){
        $ordercode = I('post.ordercode');
        $rs = $this->deletedata('group_order',array('ordercode'=>$ordercode));
        if ($rs) {
            $this->ajaxReturn(array('code'=>6,'msg'=>'删除成功'));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'删除失败'));
        }
    }
    // 个人中心写入缓存
    public function payWrite(){
        $sub_ordercode = I('post.sub_ordercode');
        $data = $this->finddata('group_order_buy',array('sub_ordercode'=>$sub_ordercode));
        if ($data) {
            $_SESSION['pay']['url'] = array(
                'addordesUrl'=>U('GroupMall/payOrder'),
                'successUrl'=>U('Status/status',array('type'=>1)),
                'returnUrl'=>U('GroupMall/order',array('status'=>1)),
            );
            $_SESSION['pay']['data'] = array(
                'table'=>'group_order_buy',
                'ordercode'=>$sub_ordercode,
                'money'=>$data["paymoney"],
                'title'=>'拼团订单支付',
            );
            $group_order_buy = array(
                "ordercode"     =>  $data['ordercode'],
                "sub_ordercode" =>  $sub_ordercode,
                "group_goods_id"=>  $data["group_goods_id"],
                "num"           =>  $data["num"],
                "price"         =>  $data["price"],
                "allmoney"      =>  $data['allmoney'],
                "paymoney"      =>  $data['allmoney'],
                "address_id"    =>  $data['address_id'],
                "members_id"    =>  $data['members_id'],
                "attr"          =>  json_encode($data["attr"]),
                "messages"      =>  $data['messages'],
            );
           $_SESSION["group_order_buy"] = $group_order_buy;
           $this->ajaxReturn(array('code'=>6,'msg'=>'写入成功'));
        }else{
           $this->ajaxReturn(array('code'=>1,'msg'=>'无此订单'));
        }
    }
    // 查看快递
    public function logistics(){
       $sub_ordercode = I('post.sub_ordercode');
       $logistics =M('group_order_buy')->field('logistics_id,logistics_code')->where(array('sub_ordercode'=>$sub_ordercode))->find();
       $logistics_name = $this->finddata('logistics',array('id'=>$logistics['logistics_id']),'name');
       if ($logistics) {
         $logistics = array(
            'logistics_name'=>$logistics_name,
            'logistics_code'=>$logistics['logistics_code']
         );
         $this->ajaxReturn(array('code'=>6,'msg'=>'获取成功','data'=>$logistics));
       }else{
          $this->ajaxReturn(array('code'=>1,'msg'=>'暂无快递单号'));
       }
    }
    public function share(){
        $Wechat = new WechatApiController();
        $url = $share['url'] ? $share['url'] : "http://".$_SERVER['HTTP_HOST'].$_SERVER["REDIRECT_URL"].$_SERVER['REDIRECT_URL'];
        $nickname = $_SESSION['wechat']['nickname'];
        $name = str_replace("*", $nickname,$share['name']);
        $title = str_replace("*", $nickname,$share['title']);
        $pic = $share['pic'] ? $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$share['pic'] : $_SESSION['wechat']['headimgurl'];
        $sharedata = $Wechat->wechat_share($url,$pic,$name,$title);
    }
    // 订单详情
    public function order_details(){
        $sub_ordercode = I('get.sub_ordercode');
        $orderBuy = D('GroupOrderBuyRelation')->relation(true)->where(array('sub_ordercode'=>$sub_ordercode))->find();
        $attr = json_decode($orderBuy['attr'],1);
        $orderBuy['attr'] =$attr ;
        $data = D('GroupOrderRelation')->relation(true)->where(array('ordercode'=>$orderBuy['ordercode']))->find();
        $data['child'] = $orderBuy;
        $this->data = $data;
        // 分享Api
        $Wechat = new WechatApiController();
        $url = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST']."/Index/GroupMall/shareOrder?ordercode=".$data["ordercode"];
        $nickname = $_SESSION['wechat']['nickname'];
        $name = $nickname."邀您一起拼".$orderBuy['goods_name'];
        $title = "我在'".getBase("name")."'拼".$orderBuy['goods_name']."你也来吧！";
        $pic = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$orderBuy['goods_pic'];
        $sharedata = $Wechat->wechat_share($url,$pic,$name,$title);
        $this->sharedata = $sharedata;
        $this->title = "订单详情";
        $this->display();
    }

    // 用户点击分享订单后出来的页面
    public function shareOrder(){
        $ordercode = I("get.ordercode");
        // 获取总订单信息
        $data = D('GroupOrderRelation')->relation(true)->where(array('ordercode'=>$ordercode))->find();
        // dump($data);
        // 获取已参团的人员信息
        $buyUser = D("GroupOrderBuyRelation")->relation("members")->where(array('ordercode'=>$ordercode,'status'=>1))->field("members_id,status")->select();
        $this->buyUser = $buyUser;

        $this->remain = ($data['group_num']-count($buyUser));
        $where = array(
            'ordercode'   =>  $ordercode,
            'members_id'  =>  $this->members_id,
            'status'      =>  1
        );
        $is_buy = M("group_order_buy")->where($where)->count();
        $this->is_buy = $is_buy;
        // dump($is_buy);
        // 获取推荐的商品
        $goods = $this->selectdata("group_goods",array('status'=>0,'is_red'=>1));
        $this->goods = $goods;
        $this->data = $data;
        $this->title="我要参团";
        $this->display();
    }
}