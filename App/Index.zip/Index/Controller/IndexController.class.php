<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class IndexController extends CommonController {
	/*入口首页*/
    public function index(){
    	/* 获取首页banner图 */
        $banner = $this->getBanner(1);
        $this->banner = $banner;
        /* 获取首页头部导航 */
        $index_nav = $this->selectdata('top_nav',array('status'=>0,'place'=>1),'','sort DESC');
        $this->index_nav = $index_nav;
        /* 获取首页栏目 */
        $index_column = $this->selectdata('mall_index_column',array('status'=>0));
        $this->index_column = $index_column;
        /* 获取首页广告位 */
        $index_adv =  $this->selectdata('mall_index_adv',array('status'=>0,'is_red'=>1));
        $this->index_adv = $index_adv;
        /* 获取首页广告位 */
        $is_index_product = $this->getConfig('is_index_product');
        if ($is_index_product==0) {
            $index_product =  $this->selectdata('mall_index_product',array('status'=>0,'is_red'=>1));
            $this->index_product = $index_product;
        }
        /* 获取推荐商品 */
        $goods_red = $this->selectdata('goods',array('status'=>0,'is_red'=>1));
        $this->goods_red = $goods_red;
        
        /* 微信公众号分享 */
        $this->sharedata = $this->share(1);
        /* 判断用户是否关注 */
        $Wechat = new WechatApiController();
        $subscribe = $Wechat->get_subscribe($_SESSION['wechat']['openid']);
        // dump($subscribe);
        $this->subscribe = $subscribe;
        // 新人优惠专项
        $welfare_status = getBase("welfare_status");   // 新人优惠开启状态
        /* welfare_status 判读是否开启新用户福利 
         * is_new 判断是否新用户
        */
        $is_new = S('is_new');                 // 判断是否新人
        if ($welfare_status==1 && $is_new==1) {
            $base = $this->getConfig();
            $coupon = $this->finddata('coupon',array('id'=>$base['coupon_id'],'name'));
            $base['coupon_name'] = $coupon['name'];
            $this->base = $base;
            $this->is_welfare = 0;
        }else{
            $this->is_welfare = 1;
        }
    	$this->display();
    }
}