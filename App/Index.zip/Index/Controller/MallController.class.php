<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class MallController extends CommonController {
    // 商品分类页
    public function cate(){
        $cate_top = $this->selectdata('goods_cate',array('status'=>0,'pid'=>0),'','sort ASC');
        $this->cate_top = $cate_top;
        $this->title="商品分类";
    	$this->display();
    }
    // 商品列表
    public function goodslist(){
        /* 模糊查询商品 */
        $name = I('get.name');
        if ($name) {
           $where['name'] = array("like","%$name%");
        }
        $type = I('get.type');
        if ($type) {
           $where[$type] = 1;
           switch ($type) {
                case 'is_red':
                   $title = "推荐商品";
                   break;
                case 'is_new':
                   $title = "新品推荐";
                   break;
           }
        }
        /*判断是否有传过来的分类id*/
        $cate_id = I('get.cate_id');
        if ($cate_id) {
		   $goods_cate = M('goods_cate')->where(array('status'=>0))->select();
		   $idStr = getIdStr($goods_cate,$cate_id);
		   $where['goods_cate_id '] = array('in',$idStr);
           $name = M('goods_cate')->where(array('id'=>$cate_id,'status'=>0))->getField('name');
           $title = $name;
        }
        $where['status'] = 0;
        $data = $this->selectdata('goods',$where,'');
        // dump($data);
        $this->data = $data;
        $this->logo = $this->getConfig('logo');
        $this->conf = $this->getConfig();
        $this->title= $title ? $title : "全部商品";
        $this->display();
    }
    // 商品详情页
    public function details(){
        $goods_id = I('get.id');
        $data = D('GoodsRelation')->relation(true)->where(array('id'=>$goods_id))->find();
        $data['many_pic']= json_decode($data['many_pic']);
        // 判断用户该商品是否收藏
        $collict_id = M('collect')->where(array('goods_id'=>$goods_id,'members_id'=>$this->members_id))->count();
        $data['collict_id'] = $collict_id;
        $this->data = $data;
        $this->hospital_tel = $this->getConfig('hospital_tel');
        $this->title= $data['name'];
        $this->sharedata = $this->sharePackage($data['pic'],$data['name'],$data['title']);
        $countWhere = "goods_id ='".$goods_id."' and status = 0 ";
        $count = M("order_evaluate")->where($countWhere)->count();
        $list = D("EvaluateRelation")->relation(true)->where($countWhere."and star >=4")->limit(3)->order('id desc')->select();
        $evaluate = array(
            'count'=>$count,
            'list'=>$list
        );
        $this->evaluate = $evaluate;
        $this->display();
    }
    /* 商品全部评论 */
    public function evaluate(){
        $goods_id = I('get.goods_id');
        $type = I('get.type');
        $where = "goods_id ='".$goods_id."' and status = 0 ";
        switch ($type) {
            case 1:
                $where.= "and star >=4";
                break;
            case 2:
                 $where.= "and (star = 3 or star = 2)";
                break;
            case 3:
                $where.= "and star=1";
                break;
        }
        $evaluate = D("EvaluateRelation")->relation(true)->order('id desc')->where($where)->select();
        $countWhere = "goods_id ='".$goods_id."' and status = 0 ";

        $count3 = D("EvaluateRelation")->relation(true)->where($countWhere."and star=1")->count();
        $count2 = D("EvaluateRelation")->relation(true)->where($countWhere."and (star = 3 or star = 2)")->count();
        $count1 = D("EvaluateRelation")->relation(true)->where($countWhere."and star >=4")->count();
        $count6 = D("EvaluateRelation")->relation(true)->where($countWhere)->count();
        $this->evaluate = $evaluate;
        $this->count = array('count1'=>$count1,'count2'=>$count2,'count3'=>$count3,'count6'=>$count6,);
        $this->display();
    }
    public function shopcart(){
        import('Class.Cart',APP_PATH);
        $cart = new \Cart();
        $shopcart = $cart->getShopCart();
        // dump($shopcart);
        $this->shopcart = $shopcart;
        $this->display();
    }
    /* 订单确认页面 */
     public function confirm(){
        //获取用户收货地址
        $address_id = I('get.address_id');
        if ($address_id){
            $address = $this->finddata('address',array('id'=>$address_id));
        }else{
            $address = $this->finddata('address',array('members_id'=>$this->members_id,'default'=>1));
        }
        $this->address = $address;
        /* 立即购买 */
        $goods =$_SESSION['buy'];
        if ($goods) {
            import('Class.Cart',APP_PATH);
            $this->goods = $goods;
            /* 统计商品总价格 */
            $cart = new \Cart();
            $paydata = $cart->getItemPrice($goods);
            // dump($paydata);
        }else{
            $this->redirect('Members/order',array('status'=>0));
        }

        /* 查找可用优惠券 */
        $where = array(
            'members_id'=>$this->members_id,
            'status'=>0,
            'full_price'=>array('lt',$paydata['price'])
        );
        $coupon = $this->selectdata('get_coupon',$where);
        $this->coupon = $coupon;

        /* 判断是否包邮是否要加邮费 */
        $postage = getBase("postage");
        if ($postage) {
            $paydata['price'] = $paydata['price'] + $postage;
        }
        $this->paydata = $paydata;
        $this->title = "订单确认";
        $this->display();
    }

    /* 添加订单的方法 */
    public function addOrder(){
        $buydata = $_SESSION['buy'];
        if (!$buydata) {
           $this->ajaxReturn(array('code'=>1,'msg'=>'请重新选购'));
        }
        import('Class.Cart',APP_PATH);
        /* 统计商品总价格 */
        $cart = new \Cart();
        $coupon_code = I('post.coupon_code');
        $paydata = $cart->getItemPrice($buydata);
        $messages = I('post.messages');
        $address_id = I('post.address_id');
        $ordercode = randomCode();
        $allmoney = $paydata['price'];
        $allnum = $paydata['num'];
        // 判断用户是否使用优惠券
        if ($coupon_code){
            $coupon = M('get_coupon')->where(array('coupon_code'=>$coupon_code))->find();
            $paymoney = sprintf("%01.2f",$allmoney-$coupon['price']);
        }else{
            $paymoney = $allmoney;
        }
         /* 判断是否包邮是否要加邮费 */
        $postage = getBase("postage");
        if ($postage) {
            $paymoney = $paymoney + $postage;
            $allmoney = $allmoney + $postage;
        }
        $address = $this->finddata('address',array('id'=>$address_id));
        $order = array(
            'ordercode'   => $ordercode,
            'allnum'      => $allnum,
            'allmoney'    => $allmoney,
            'paymoney'    => $paymoney,
            'coupon_code' => $coupon_code,
            'members_id'  => $this->members_id,
            'username'    => $address['username'],
            'userphone'   => $address['userphone'],
            'province'    => $address['province'],
            'city'        => $address['city'],
            'area'        => $address['area'],
            'details'     => $address['details'],
            'messages'    => $messages,
            'create_time' => time()
        );
        $orderlist = array();
        foreach($buydata as $k => $v){
           $orderlist[] = array(
               'ordercode'=>$ordercode,
               'goods_id'=>$v['id'],
               'buy_num'=>$v['num'],
               'goods_price'=>$v['price'],
               'goods_pic'=>$v['pic'],
               'goods_name'=>$v['name'],
               'goods_attr'=>json_encode($v['attr'] ? $v['attr']:0)
            );
        }
        $rs1 = M('mall_order')->add($order);
        $rs2 = M('mall_order_list')->addAll($orderlist);
        if ($coupon_code) {
            $couponArr = array(
                'status'=>1,
                'used_time'=>time(),
                'order_id'=>$rs1
            );
            M('get_coupon')->where(array('coupon_code'=>$coupon_code))->data($couponArr)->save();
        }
        $_SESSION['pay']['url'] = array(
            'addordesUrl'=>U('Mall/payOrder'),
            'successUrl'=>U('Status/status',array('type'=>1)),
            'returnUrl'=>U('Members/order'),
        );
        $_SESSION['pay']['data'] = array(
            'table'=>'mall_order',
            'ordercode'=>$ordercode,
            'money'=>$paymoney,
            'title'=>'订单支付',
        );
        if($rs1 && $rs2){
            foreach ($buydata as $k => $v) {
                import('Class.Cart',APP_PATH);
                $cart = new \Cart();
                $cart->delItem($v['id'],$v['attr_str']);
            }
            unset($_SESSION['buy']);
            $this->ajaxReturn(array('code'=>6,'msg'=>'订单添加成功','order_id'=>$rs1));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'订单添加失败'));
        }
    }
    
    /* 添加订单 */
    public function payOrder(){
        if ($_SESSION["pay"]["data"]["ordercode"] && $this->members_id) {
            $data = array(
                'status'      => 1,
                "pay_type"    => 2,
                'update_time' => time()
            );
            $where = array('ordercode'=>$_SESSION["pay"]["data"]["ordercode"]);
            $rs = M("mall_order")->where($where)->data($data)->save();
            if ($rs) {
                 $this->ajaxReturn(array('code'=>6,'msg'=>'订单添加成功'));
            }
        }
    }

    public function evaluateHandel(){
       $data = I('post.data');
       foreach ($data as $k => $v) {
           $data[$k]['create_time'] = time();
           $data[$k]['members_id'] = $_SESSION['wechat']['id'];
       }
       $rs = M('order_evaluate')->addAll($data);
       if($rs){
            $this->ajaxReturn(array('code'=>6,'msg'=>'成功'));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'操作失败'));
        }
    }

    // 领取优惠券
     public function coupon(){
        $members_id = $_SESSION['wechat']['id'];
        $data = $this->selectdata('coupon',array('status'=>0));
        foreach($data as $k=>$v){
            $where = array(
               "members_id"=>$members_id,
               "status"=>0,
               "coupon_id"=>$v['id']
            );
            $is_have = M("get_coupon")->where($where)->count();
            $data[$k]['is_have'] = $is_have ? $is_have : 0;
        }
        $this->data = $data;
        $this->title = "优惠券";
        $this->display();
    }
   
}