<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class MembersController extends CommonController {
    public function __construct(){
    	parent::__construct();
	}
    /* 自然人-----------会员中心首页 */
    public function index(){
        // dump($this->members_id);
    	$member = M('members')->where(array('id'=>$this->members_id))->find();
        $where = array('members_id'=>$this->members_id);
        $member['collect'] = $this->countdata('collect',$where);
        $allnews = $this->countdata('news',array('members_id'=>$this->members_id,'status'=>0));
        $looknews = $this->countdata('news_search',$where);
        $member['news'] = $allnews-$looknews;
         /* 判断是否分销商 */
        $agent = $this->finddata('agent',array('members_id'=>$this->members_id));
        if ($agent) {
            if($agent['status']==0){
                $member['is_agent'] = 1;  /* 在审核 */
            }elseif ($agent['status']==1) {
                $member['is_agent'] = 2;   /* 已通过，是分销商 */
            }elseif ($agent['status']==2) {
                $member['is_agent'] = 3;   /* 申请分销商被拒绝 */
            }
        }else{
            $member['is_agent'] = 0;
        }
        // dump($agent);
        $this->member = $member;
        $status0 = $this->countdata('mall_order',array('status'=>0,'members_id'=>$this->members_id));
        $status1 = $this->countdata('mall_order',array('status'=>1,'members_id'=>$this->members_id));
        $status2 = $this->countdata('mall_order',array('status'=>2,'members_id'=>$this->members_id));
        $status3 = $this->countdata('mall_order',array('status'=>3,'members_id'=>$this->members_id));
        $count = array(
            'status0'=>$status0,
            'status1'=>$status1,
            'status2'=>$status2,
            'status3'=>$status3,
        );
        $this->count = $count;
        $this->title = "会员中心";
    	$this->display();
    }
    /* 自然人-----------会员中心首页 */
    public function applyAgent(){
        $id = I('get.id');
        $this->title = "分销商申请";
        $this->display();
    }
    /* 分销商-----------会员中心首页 */
    public function applyAgentHandel(){
        $data = I('post.');
        $data['workcode'] = randomCode(2,6);
        $data['create_time'] = time();
        $data['members_id'] = $this->members_id;
        $data['work_code'] = rand(100000,999999);
        $arr = explode(',',$data['address']);
        $data['province'] = $arr[0];
        $data['city'] = $arr[1];
        $data['area'] = $arr[2];
        $rs = M('agent')->data($data)->add();
        if ($rs){
            $this->ajaxReturn(array('code'=>6,'msg'=>"申请提交成功"));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>"操作失败"));
        }
    }
    /* 自然人-----------会员资料 */
    public function members_info(){
        $data = M('members')->where(array('id'=>$this->members_id))->find();
        $this->data = $data;
        $this->title = "我的资料";
        $this->display();
    }
        /* 自然人-----------绑定手机号 */
    public function upinfo_phone(){
        $data = M('members')->where(array('id'=>$this->members_id))->find();
        $this->data = $data;
        $this->title='绑定手机号';
        $this->display();
    }
    /* 自然人-----------异步绑定手机号 */
    public function upinfo_phoneHandel(){
        $session_phone = $_SESSION['msg']['userphone'];
        $userphone = I('post.userphone');
        $session_msgcode = $_SESSION['msg']['msgcode'];
        $msgcode = I('post.msgcode');
        if ($session_msgcode != $msgcode){
            $this->ajaxReturn(array('code'=>'1','msg'=>'验证码错误'));
        }
        $status = M('members')->where(array('id'=>$this->members_id,'userphone'=>$userphone))->count();
        if($status) {
            $this->ajaxReturn(array('code'=>'2','msg'=>'该手机号已经被绑定'));
        }
        if ($session_msgcode == $msgcode && $session_phone == $userphone) {
            $data = array('userphone'=>$userphone);
            if(M("members")->where(array('id'=>$this->members_id))->data($data)->save()){
                $this->ajaxReturn(array('code'=>'6','msg'=>'绑定成功'));
            }else{
                $this->ajaxReturn(array('code'=>'4','msg'=>'绑定失败'));
            }
        }else{
             $this->ajaxReturn(array('code'=>'3','msg'=>'手机号和验证码不符合'));
        }
    }
    /* 自然人-----------异步修改会员字段 */
    public function upfield_info(){
        if (!IS_AJAX) E('非法请求');
        $fields = I('post.fields');
        $value = I('post.value');
        $data = array(
             $fields=>$value,
             "update_time"=>time()
        );
        $rs = M('members')->where(array('id'=>$this->members_id))->save($data);
        if ($rs){
            $this->ajaxReturn(array('code'=>6,'msg'=>'success'));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'error'));
        }
    }
    /* 自然人-----------更新地址 */
    public function upfield_info_address(){
        if (!IS_AJAX) E('非法请求');
        $address = I('post.address');
        $arr = explode(',',$address);
        $data = array(
            'province'=>$arr[0],
            'city'=>$arr[1],
            'area'=>$arr[2],
            'update_time'=>time()
        );
        $rs = M('members')->where(array('id'=>$this->members_id))->save($data);
        if($rs){
            $this->ajaxReturn(array('code'=>6,'msg'=>'success'));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>'error'));
        }
    }
    public function messages(){
        $this->title= "我要反馈";
        $this->display();
    }
    /* 帮助中心 */
    public function help(){
        $this->help = $this->getConfig('help');
        $this->title = "帮助中心";
        $this->display();
    }
    /*我的收藏*/
    public function  collect(){
        $data = $this->selectdata('collect',array('members_id'=>$this->members_id));
        foreach ($data as $k => $v) {
            $goods = M('goods')->where(array('id'=>$v['goods_id']))->find();
            $data[$k]['pic'] = $goods['pic'];
            $data[$k]['name'] = $goods['name'];
            $data[$k]['price'] = $goods['price'];
        }
        $this->data = $data;
        // dump($data);
        $this->title = '我的收藏';
        $this->display();
    }
    public function address(){
        $this->data = $this->selectdata('address',array('members_id'=>$this->members_id));
        $this->display();
    }
    public function address_edit(){
        $id =I('get.id');
        if ($id) {
           $this->data = $this->finddata('address',array('id'=>$id,'members_id'=>$this->members_id));
        }
        $this->display();
    }
    /* 订单状态 */
    public function order(){
         // dump();
        $members_id = I('get.members_id');
        $status = $_GET['status'];
        if(isset($status)){
            $where['status'] = $status;
            $where['members_id'] = $this->members_id;
        }else{
            $where['members_id'] =$members_id ? $members_id:$this->members_id;
            if($members_id){
                $where['status'] = array('egt',1);
            }
        }
        $data = D('OrderRelation')->relation(true)->where($where)->order('id desc')->select();
        foreach ($data as $k => $v) {
            $list = D('OrderListRelation')->relation(true)->where(array('ordercode'=>$v['ordercode']))->select();
            foreach ($list as $key => $val) {
                $goods_attr = json_decode($val['goods_attr'],1);
                $list[$key]['goods_attr'] =$goods_attr ;
            }
            
            $data[$k]['child'] = $list;
        }
        $this->data = $data;
        $this->title="我的订单";
        $this->display();
    }
    /* 我的积分记录 */
    public function point(){
        $data = $this->selectdata('point_change',array('members_id'=>$this->members_id));
        $where = array(
            'members_id'=> $this->members_id,
            'point'=>array('lt',0)
        );
        $have = $this->finddata('members',array('id'=>$this->members_id),'point');
        $used = M('point_change')->where($where)->sum('point');
        $count = array('have'=>$have,'used' =>$used);
        $this->count = $count;
        $this->data = $data;
        $this->title = "我的积分";
        $this->display();
    }
    /* 订单评价 */
    public function order_evaluate(){
        $ordercode = I('get.ordercode');
        if ($ordercode) {
            $where = array('ordercode'=>$ordercode);
            $data = D('OrderListRelation')->relation(true)->where($where)->select();
            $this->data = $data;
        }
        $this->title = "评价";
        $this->display();
    }
    /* 我的优惠券 */
    public function coupon(){
        header("Content-type:text/html;charset=utf-8");
        $coupon = $this->selectdata('get_coupon',array('members_id'=>$this->members_id));
        $data = array();
        foreach ($coupon as $k => $v){
            if ($v['status']==0) {
                $data['status0'][] =$v; 
            }elseif ($v['status']==1) {
                $data['status1'][] =$v; 
            }elseif ($v['status']==2) {
                $data['status2'][] =$v; 
            }
        }
        $this->data = $data;
        $this->title="我的优惠券";
        $this->display();
    }
    public function order_details(){
        $ordercode = I('get.ordercode');
        $data = D('OrderRelation')->relation(true)->where(array('ordercode'=>$ordercode))->find();
        if (!$data) {
            $this->redirect('Members/order');
        }
        $list = D('OrderListRelation')->relation(true)->where(array('ordercode'=>$ordercode))->select();
	    foreach ($list as $key => $val) {
			$goods_attr = json_decode($val['goods_attr'],1);
			$list[$key]['goods_attr'] =$goods_attr ;
		}       
	    $data['child'] = $list;
		// dump($data);
        $this->data = $data;
        $this->title = "订单详情";
        $this->display();
    }
    public function rechange(){
        $data = $this->selectdata('money_package',array('status'=>0));
        $this->data = $data;
        $this->title = "余额充值";
        $this->display();
    }
    public function rechargeHandel(){
        $paydata = $_SESSION['pay'];
        $data = array(
            "money"       =>    $paydata['data']['money'],
            "members_id"  =>    $this->members_id,
            "send_money"  =>    $paydata['data']['send_money'],
            "create_time" =>    time()
        );
        $rs = $this->adddata('money_recharge',$data);
        if($rs){
            $this->ajaxReturn(array('code'=>6,'msg'=>'订单添加成功'));
        }else{
            $this->ajaxReturn(array('code'=>3,'msg'=>'订单添加失败，请稍后重试'));
        }
    }
    public function order_refundType(){
        $goods_list_id = I('get.goods_list_id');
        $where = array("id"=>$goods_list_id);
        $data = D("mall_order_list")->where($where)->find();
        if ($data['goods_attr']) {
            $data['goods_attr'] = json_decode($data['goods_attr'],1);
        }
        // dump($data);
        $this->data = $data;
        $this->title = "申请售后";
        $this->display();
    }
    public function order_refund(){
        $goods_list_id = I('get.goods_list_id');
        $where = array("id"=>$goods_list_id);
        $data = D("OrderListRelation")->relation(true)->where($where)->find();
        if ($data['goods_attr']) {
            $data['goods_attr'] = json_decode($data['goods_attr'],1);
        }
        $this->title = I('get.type') ? "退款申请":"退货退款申请";
        $this->data = $data;
        $this->display();
    }
}