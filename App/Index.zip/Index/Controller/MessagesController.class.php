<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class MessagesController extends CommonController {
    /* 自然人-----------会员中心首页 */
    public function index(){
        $data = D('MessagesRelation')->relation(true)->where(array('id'=>$agent_id))->find();
        $this->data = $data;
        $this->title = "我是分销商";
    	$this->display();
    }
}