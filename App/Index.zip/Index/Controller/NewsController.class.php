<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class NewsController extends CommonController {
	//新闻列表页
    public function index(){
    	$data = $this->selectdata('news',array('status'=>0),'','id desc');
        foreach ($data as $k => $v) {
            $where = array(
                'members_id'=>$this->members_id,
                'news_id'=>$v['id']
            );
            $is_have = $this->countdata('news_search',$where);
            $data[$k]['is_read'] = $is_have;
        }
        // dump($data);
    	$this->data = $data;
    	$this->title="最新消息";
    	$this->display();
    }
    //新闻详情页
    public function details(){
    	$id = I('get.id');
        if ($id) {
            $data = $this->finddata('news',array('status'=>0,'id'=>$id));
            $is_have = M('news_search')->where(array('members_id'=>$this->members_id,'news_id'=>$id))->count();
            if (!$is_have) {
                $lookarr = array('news_id'=>$id,'members_id'=>$this->members_id);
                M('news_search')->data($lookarr)->add();
            }
            /* click字段加一 */
            M('news')->where(array('id'=>$id))->setInc('click');
            // 分享准备
            $url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUSET_URL'].$_SERVER['REDIRECT_URL'];
            $img = $_SESSION['wechat']['headimgurl'];
            $title = $data['name'];
            $desc = $data['title'];
            $Wechat = new WechatApiController();
            $sharedata = $Wechat->wechat_share($url,$img,$title,$desc);
            $this->sharedata=$sharedata;
            $this->title=$data['title'];
        }
    	$this->data = $data;
    	$this->display();
    }
}