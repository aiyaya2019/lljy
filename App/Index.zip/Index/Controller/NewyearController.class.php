<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class NewyearController extends Controller{
	public function __construct(){
	    parent::__construct();
		
	}
	/*
	//自动运行方法判断是否写入session
	Public function _initialize(){
		if($_SESSION['wechat'] == ""){
			$this->wechat = new WechatController();
			  if(!isset($_SESSION['wechat']['openid'])){
			   $this->wechat->get_wechat_info();
		    }
		}
	}*/
	//祝福视图
	public function index(){
		$data = M("newyear")->where(array('id'=>$_GET['id']))->find();
		if($data){
			$this->data = $data;
		}else{
			$this->redirect(MODULE_NAME.'/Newyear/edit');
		}
		$this->title = "送给一张新年贺卡";
		$this->display();
	}
	public function edit(){
		$this->display();
	}
	//异步表单处理
	public function edithandle(){
		$data = I("post.");
		$data['time'] = time();
		if($id = M("newyear")->data($data)->add()){
			echo $id;
		}else{
			echo no;
		}
	}
}