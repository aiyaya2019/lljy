<?php
namespace Index\Controller;
use Think\Controller;
class PayController extends CommonController{
	//微信支付统一页面
	public function wxpay(){
         // dump($_SESSION);
        header("Content-type:text/html;charset=utf-8");
        if(isset($_SESSION['pay']['data'])){
            $pay = $_SESSION['pay'];
            $jsApiParameters = $this->weixinPay($pay['data']['table'],$pay['data']['title'],$pay['data']['money'],$pay['data']['ordercode']);
            //dump($jsApiParameters);
            $this->jsApiParameters = $jsApiParameters;
            $money = $this->finddata('members',array('id'=>$this->members_id),'money');
            $this->money = $money ? $money:0;
        }
        $this->title = $_SESSION['pay']['data']['title'];
        $this->display();
    }
    // 余额支付
    public function balance(){
        if(!IS_AJAX) die("非法操作");
        $table = I('post.table');
        $paymoney = I('post.paymoney');
        $c_members_id = I('post.members_id');
        $members_id = $this->members_id;
        $c_ordercode = I('post.ordercode');
        $ordercode = $_SESSION['pay']['data']['ordercode'];
        if ($c_ordercode != $ordercode) {
           die("非法操作");
        }
        if ($c_members_id != $members_id) {
           die("非法操作");
        }
        $money = $this->finddata("members",array('id'=>$members_id),"money");
        if ($paymoney>$money) {
            $this->ajaxReturn(array('code'=>2,'msg'=>"余额不足，请换种方式支付"));
        }
        $data2 = array(
            "money"       =>    "-".$paymoney,
            "type"        =>    "余额支付",
            "msg"         =>    "支付该订单：".$ordercode,
            "members_id"  =>    $members_id,
            "create_time" =>    time()
        );
        $rs1 = $this->adddata('money_change',$data2);
        if ($rs1) {
            $this->ajaxReturn(array('code'=>6,'msg'=>"操作成功"));
        }else{
            $this->ajaxReturn(array('code'=>1,'msg'=>"操作失败"));
        }
    }
}
?>