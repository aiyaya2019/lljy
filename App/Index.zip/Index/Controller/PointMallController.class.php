<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class PointMallController extends CommonController {
    public function index(){
        /* 获取首页banner图 */
        $banner = $this->getBanner(2);
        $this->banner = $banner;
        /* 获取首页头部导航 */
        $top_nav = $this->selectdata('top_nav',array('status'=>0,'place'=>2),'','sort ASC');
        $this->top_nav = $top_nav;
         /* 模糊查询商品 */
        $name = I('get.name');
        if ($name) {
           $where['name'] = array("like","%$name%");
        }
        $where['status'] = 0;
        $data = D('PointGoodsRelation')->relation(true)->where($where)->select();
        $this->data = $data;

        $this->title = "积分商城";
        $this->display();
    }
    public function details(){
    	$id = I('get.id');
    	if ($id) {
    		$data = D('PointGoodsRelation')->relation(true)->where(array('id'=>$id))->find();
    		$data['many_pic']= json_decode($data['many_pic']);
            $this->data = $data;
            $point = $this->finddata('members',array('id'=>$this->members_id),'point');
            $this->point = $point;
            $this->title = $data['name'];
    	}
    	$this->display();
    }
    // 将订购商品存入session
    public function buySession(){
        if(!IS_AJAX) E("页面不存在");
        $goods_id = I('post.goods_id','0');
        $goods_num = I('post.goods_num','0');
        // 获取用户的剩余积分
        $allPoint = $this->finddata('members',array('id'=>$this->members_id),'point');
        $data = M('point_goods')->field('id,point_num,save_num')->where(array('id'=>$goods_id))->find();
        // 判断积分是否充足
        $usePoint = intval($data['point_num'] * $goods_num);
        if($usePoint > $allPoint){
            $this->ajaxReturn(array('code'=>1,'msg'=>"积分不足，集够了在来吧"));
        }
        // 判断库存是否充足
        if($data['save_num'] >= $goods_num){
            $_SESSION['shopcart']['goods_id'] = $goods_id;
            $_SESSION['shopcart']['goods_num'] = $goods_num;
            $this->ajaxReturn(array('code'=>6,'msg'=>'success'));
        }else{
            $this->ajaxReturn(array('code'=>2,'msg'=>'库存不足','save_num'=>"库存不足，可兑换".$data['save_num']."个"));
        }
        
    }
    // 确认购买订单页
    public function paybuy(){
        $goods_id = $_SESSION['shopcart']['goods_id'];
        $_SESSION['shopcart']['ordercode'] = randomCode();
        $data = M('point_goods')->field('content',true)->where(array('id'=>$goods_id))->find();
        $data["buy_num"] = $_SESSION['shopcart']['goods_num'];
        $submitArr = json_decode($data["submit"]);
        $submit = C("submit");
        foreach ($submit as $k => $v) {
            $submit[$k]["is_need"] = in_array($v["name"],$submitArr);
        }
        $data["submit"] = $submit;
      
        $this->data = $data;
        $this->ordercode = $_SESSION['shopcart']['ordercode'];
        $this->title="确认订单";
        $this->display();
    }
         //订单处理
    public function buyHandle(){
        if (!IS_AJAX) E("页面不存在");
        $goods_id = I('post.goods_id','0');
        $goods = M("point_goods")->where(array('id'=>$goods_id))->find();
        $data = I('post.');
        $buynum = $_SESSION['shopcart']['goods_num'];
        $ordercode = $_SESSION['shopcart']['ordercode'];
        $usedpoint = $goods["point_num"] * $buynum;
        // 判断订单是否重复提交
        $isHave = M("point_order")->where(array('ordercode'=>$ordercode))->count();
        if($isHave) {
            $this->ajaxReturn(array('code'=>4,'msg'=>"请不要重复提交订单"));
        }
         // 判断是否有人恶意提交
        if ($data["ordercode"] != $ordercode) {
            $this->ajaxReturn(array('code'=>3,'msg'=>"火星错误，请联系客服"));
        }
        $allpoint = $this->finddata('members',array('id'=>$this->members_id),'point');
        if($usedpoint>$allpoint){
            $this->ajaxReturn(array('code'=>2,'msg'=>"积分不足，集够了在来吧"));
        }
        if ($data['address']) {
            $address = $data['address'].",".$data['details'];
        }
        $data = array(
            'ordercode'=>$ordercode,
            'username'=>$data['name'] ? $data['name']:"",
            'userphone'=>$data['phone'] ? $data['phone']:"",
            'address'=>$address?$address:"",
            'members_id'=>$this->members_id,
            'point_goods_id'=>$goods_id,
            'buynum'=>$buynum,
            'usedpoint'=>$usedpoint,
            'create_time'=>time(),
        );
        // 添加订单记录
        $rs1 = M("point_order")->data($data)->add();
        //订单完成更新积分记录
        $data = array(
            'members_id' => $this->members_id,
            'point'=> '-'.$usedpoint,
            'type'=>1,
            'msg'=>'积分兑换商品：'.$goods['name'],
            'create_time' =>time(),
        );
        $rs2 = M('point_change')->data($data)->add();
        if($rs1 && $rs2){
            unset($_SESSION['shopcart']);
            $this->ajaxReturn(array('code'=>1,'msg'=>"兑换成功"));
        }
    }
}