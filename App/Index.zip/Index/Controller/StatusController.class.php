<?php
namespace Index\Controller;
use Think\Controller;
use Think\Vender;
class StatusController extends CommonController {
	public function status(){
		$type = I('get.type');
		switch ($type) {
			case 1:
				$title = "支付成功...";
				break;
			case 2:
				$title = "申请成功...";
				break;
			case 3:
				$title = "平台拒绝...";
				break;
		}
		$this->title = $title;
		/* 判断用户是否关注 */
        $Wechat = new WechatApiController();
        $subscribe = $Wechat->get_subscribe($_SESSION['wechat']['openid']);
        // dump($subscribe);
        $this->subscribe = $subscribe;
		$this->display();
	}
}